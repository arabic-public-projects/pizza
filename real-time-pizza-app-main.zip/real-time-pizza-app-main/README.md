# real-time-pizza-app

<br/>

### real time pizza delevery app using node js express mongodb as a database shocket.io for real time comminication.


<p align="center">

  <img src="https://github.com/aliashfak178/PICS/blob/main/PICS/pizza%20app.JPG" alt="Coder JPG" width="900" height="500">
  
</p>


